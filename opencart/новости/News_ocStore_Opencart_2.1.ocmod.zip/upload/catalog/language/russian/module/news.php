<?php
// Heading 
$_['heading_title']   	= 'Новости';

// Text
$_['text_more']  		= 'Читать далее...';
$_['text_date_added'] 	= 'Добавлено:';
$_['text_viewed'] 		= '(%s просмотров) ';

// Buttons
$_['button_list']     	= 'Посмотреть все';
?>
