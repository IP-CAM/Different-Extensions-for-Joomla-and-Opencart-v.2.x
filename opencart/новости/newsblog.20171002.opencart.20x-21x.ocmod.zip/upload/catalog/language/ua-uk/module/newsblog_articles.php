<?php
// Text
$_['text_more']  		= 'Читати далі...';
$_['category_more']  	= 'Усі новини...';
$_['text_date_added'] 	= 'Додано:';
$_['text_viewed'] 		= '(%s переглядів) ';

// Buttons
$_['button_list']     	= 'Переглянути все';
?>
