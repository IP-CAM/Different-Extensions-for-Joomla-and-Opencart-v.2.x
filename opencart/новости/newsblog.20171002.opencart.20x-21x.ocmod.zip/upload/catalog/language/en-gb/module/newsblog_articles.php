<?php
// Text
$_['text_more']  		= 'Read more...';
$_['text_date_added'] 	= 'Added:';
$_['text_viewed'] 		= '(%s views) ';

// Buttons
$_['button_list']     	= 'View all';
?>
