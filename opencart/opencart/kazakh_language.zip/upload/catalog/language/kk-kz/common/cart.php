<?php
// Text
$_['text_items'] = '%s тауарды(ларды) - %s';
$_['text_empty'] = 'себетте бос!';
$_['text_cart'] = 'Ашу себетке';
$_['text_checkout'] = 'Оформить заказ';
$_['text_recurring'] = 'Профиль төлемнің';