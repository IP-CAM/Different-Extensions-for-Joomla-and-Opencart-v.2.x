<?php
// Text
$_['text_currency'] = 'Валютасы';