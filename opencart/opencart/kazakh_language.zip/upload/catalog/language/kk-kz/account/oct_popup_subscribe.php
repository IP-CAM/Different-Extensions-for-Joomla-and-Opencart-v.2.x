<?php
// Button
$_['heading_title'] = 'Мәртебе жазылу';

// Text
$_['text_message_default'] = 'Ақпарат қол жетімді емес';
$_['text_message_approve'] = 'Сіздің жазылу сәтті расталды!';
$_['text_message_unsubscribe'] = 'Сіз сәтті болмайды подписку!';