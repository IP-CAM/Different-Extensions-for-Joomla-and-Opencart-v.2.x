<?php
// Heading
$_['heading_title'] = 'Серіктестік-бөлім';

// Text
$_['text_account'] = 'Кабинеті серіктес';
$_['text_my_account'] = 'учетная запись пользователя';
$_['text_my_tracking'] = 'Менің рефералы';
$_['text_my_transactions'] = 'Тарих төлемдерді';
$_['text_edit'] = 'құпия сөзіңізді ұмыттыңыз ба?';
$_['text_password'] = 'құпия сөзді Өзгерту';
$_['text_payment'] = 'Өзгерту төлем деректемелері';
$_['text_tracking'] = 'Реферальный коды';
$_['text_transaction'] = 'Көру тарихын төлемдерді';
