<?php
// Heading
$_['heading_title'] = 'Сұратылған бет жоқ!';

// Text
$_['text_error'] = 'Сұратылған бет жоқ!';