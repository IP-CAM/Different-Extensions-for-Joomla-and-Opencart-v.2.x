<?php
// Heading
$_['heading_title'] = 'Соңғы';

// Text
$_['text_tax'] = 'Без налога:';