<?php
// Heading
$_['heading_title'] = 'Қа';

// Button
$_['button_more'] = 'барлық Көрсету';