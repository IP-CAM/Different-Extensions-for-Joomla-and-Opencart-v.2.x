<?php
// Heading
$_['heading_title'] = ', Тауарлар жеңілдікпен';

// Text
$_['text_tax'] = 'Без налога:';