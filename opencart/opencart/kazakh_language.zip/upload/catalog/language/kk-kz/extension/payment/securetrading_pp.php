<?php

$_['text_title'] = 'Кредитная или дебетовая карта ';
$_['button_confirm'] = 'Подтвердить';

$_['text_postcode_check'] = 'Проверка почтового индекса: %s';
$_['text_security_code_check'] = 'Проверка CVV2: %s';
$_['text_address_check'] = 'Проверка Адреса: %s';
$_['text_not_given'] = 'Нет данных';
$_['text_not_checked'] = 'Не проверено';
$_['text_match'] = 'Соответствует';
$_['text_not_match'] = 'Не соответствует';
$_['text_payment_details'] = 'Данные платежа';

$_['entry_card_type'] = 'Тип карты';