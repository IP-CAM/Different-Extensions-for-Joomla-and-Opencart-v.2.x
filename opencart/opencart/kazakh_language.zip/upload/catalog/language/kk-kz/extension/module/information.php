<?php
// Text
$_['text_contact'] = 'бізбен';
$_['text_sitemap'] = 'Сайт картасы';