<?php
// Heading
$_['heading_title'] = 'өте Жақсы!';

// Button
$_['button_ok'] = 'Ok';

// Text
$_['text_success_add'] = 'Сіз қосылды';
$_['text_compare'] = 'салыстыру!';