<?php
$_['heading_title'] = 'В магазине eBay';