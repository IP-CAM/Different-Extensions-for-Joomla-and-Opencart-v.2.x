<?php
// Text
$_['text_title']       = '';
$_['text_description'] = 'Өзіңіз алып кету';