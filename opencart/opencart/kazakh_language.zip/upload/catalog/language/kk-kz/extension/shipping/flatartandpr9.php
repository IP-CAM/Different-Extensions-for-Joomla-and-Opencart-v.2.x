<?php
// Text
$_['text_title']       = '';
$_['text_description'] = 'Жеткізу Өмірзақ';