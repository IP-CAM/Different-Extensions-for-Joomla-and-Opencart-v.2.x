<?php
// Text
$_['text_title']  = 'Wallet One (Единая касса)';
?>