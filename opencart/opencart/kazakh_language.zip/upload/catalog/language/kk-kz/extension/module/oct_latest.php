<?php
// Heading
$_['heading_title'] = 'Жаңа';

// Text
$_['text_tax'] = 'Без налога:';