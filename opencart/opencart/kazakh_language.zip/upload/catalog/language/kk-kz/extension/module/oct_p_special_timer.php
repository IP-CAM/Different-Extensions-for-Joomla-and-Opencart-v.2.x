<?php
// Heading
$_['heading_title'] = 'Тауарлары күні';

// Button
$_['button_cart_time'] = 'Комаров-купить!';

// Text
$_['text_tax'] = 'Без налога:';