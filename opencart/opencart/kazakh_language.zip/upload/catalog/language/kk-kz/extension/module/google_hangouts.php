<?php
// Heading
$_['heading_title']  = 'Живой чат';
