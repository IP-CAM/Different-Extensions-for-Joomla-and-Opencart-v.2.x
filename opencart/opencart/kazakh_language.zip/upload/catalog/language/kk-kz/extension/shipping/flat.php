<?php
// Text
$_['text_title'] = 'Бірыңғай ставка';
$_['text_description'] = 'Тіркелген жеткізу құны';