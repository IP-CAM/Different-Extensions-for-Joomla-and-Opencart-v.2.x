<?php
$_['text_total'] = 'Барлығы';