<?php
// Text
$_['text_title']       = '';
$_['text_description'] = 'Жеткізу Магинстау 1,2,3,4,5';