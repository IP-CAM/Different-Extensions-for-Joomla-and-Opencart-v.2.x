<?php
$_['text_credit'] = 'Кредит дүкенінің';
$_['text_order_id'] = 'Тапсырыс №: #%s';