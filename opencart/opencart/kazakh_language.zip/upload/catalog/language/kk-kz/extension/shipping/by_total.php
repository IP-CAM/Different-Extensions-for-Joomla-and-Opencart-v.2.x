<?php
// Text
$_['text_title']  = 'Доставка';
$_['text_total']  = 'Сумма:'; 
?>