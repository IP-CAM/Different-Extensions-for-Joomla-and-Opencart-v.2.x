<?php
// Heading
$_['heading_title'] = 'Защитный код';

// Entry
$_['entry_captcha'] = 'Введите код';

// Error
$_['error_captcha'] = 'Введен неверный код!';
