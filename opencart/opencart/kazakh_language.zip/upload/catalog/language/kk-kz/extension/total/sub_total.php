<?php
$_['text_sub_total'] = 'Алдын-ала құны';