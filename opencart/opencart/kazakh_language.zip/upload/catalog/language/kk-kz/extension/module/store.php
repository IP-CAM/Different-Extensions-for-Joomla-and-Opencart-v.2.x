<?php
// Heading
$_['heading_title'] = 'магазин Таңдаңыз';

// Text
$_['text_default'] = 'әдепкі';
$_['text_store'] = 'Таңдаңыз дүкен, сіз кіріңіз.';