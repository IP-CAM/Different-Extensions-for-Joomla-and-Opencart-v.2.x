<?php
// Heading
$_['heading_title'] = 'кәрзеңкеге қосу';

// Text
$_['text_tax'] = ', ҚҚС-Сыз:';
