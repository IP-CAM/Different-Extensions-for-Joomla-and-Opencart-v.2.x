<?php
// Text
$_['text_title'] = 'Тегін тапсырыс беру';