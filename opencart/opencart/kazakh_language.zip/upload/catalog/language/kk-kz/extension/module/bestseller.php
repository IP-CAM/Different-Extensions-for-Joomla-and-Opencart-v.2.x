<?php
// Heading
$_['heading_title'] = 'Хиты сату';

// Text
$_['text_tax'] = 'Без налога:';