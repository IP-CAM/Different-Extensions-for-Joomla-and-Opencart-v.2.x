<?php
// Heading
$_['heading_title'] = 'Танымал';

// Text
$_['text_tax'] = 'Без налога:';