<?php
$_['error_no_odmpro_update_csv_link'] = 'ERR. 1 - Нет данных для автобоновления';
$_['error_no_token'] = 'ERR. 2 - Неправильная защита ссылки';
$_['error_template_data'] = 'ERR. 3 - Отсутствуют шаблон соответствий или настройки';
$_['error_status'] = 'ERR. 4 - Это автообновление выключено';
$_['write_success_accomplished'] = 'Запись файла успешно завершена';
include_once $_SERVER['DOCUMENT_ROOT'] .   '/admin/language/en-gb/extension/module/csv_ocext_dmpro.php';

