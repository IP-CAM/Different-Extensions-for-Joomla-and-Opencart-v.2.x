<?php
// Heading 
$_['heading_title'] = 'Біздің тауарлар';

$_['tab_latest'] = 'Жаңа түсімдер';
$_['tab_bestseller'] = 'Танымал';
$_['tab_featured'] = 'Танымал';
$_['tab_special'] = 'Акциялар';

// Text
$_['text_reviews'] = 'Негізделетін %s ерікті.';
?>