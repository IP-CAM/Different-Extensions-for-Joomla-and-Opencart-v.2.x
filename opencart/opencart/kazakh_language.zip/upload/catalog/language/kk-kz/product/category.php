<?php
// Text
$_['text_refine'] = 'Нақтылау іздеу';
$_['text_product'] = 'Тауарлар';
$_['text_error'] = 'Санат табылмады!';
$_['text_empty'] = 'бұл санатта жоқ.';
$_['text_quantity'] = 'Саны:';
$_['text_manufacturer'] = ') Өндіруші:';
$_['text_model'] = 'тауардың Коды:';
$_['text_points'] = 'Бонустық ұпайлар:';
$_['text_price'] = 'Баға:';
$_['text_tax'] = 'Без налога:';
$_['text_compare'] = 'Салыстыру тауарларды (%s)';
$_['text_sort'] = 'Сұрыптау:';
$_['text_default'] = 'әдепкі';
$_['text_name_asc'] = '(A)';
$_['text_name_desc'] = 'аты Бойынша (Я - A)';
$_['text_price_asc'] = 'баға Бойынша (өсуі)';
$_['text_price_desc'] = 'баға Бойынша (кемуі)';
$_['text_rating_asc'] = 'рейтингі Бойынша (өсуі)';
$_['text_rating_desc'] = 'рейтингі Бойынша (кемуі)';
$_['text_model_asc'] = 'моделі Бойынша (A)';
$_['text_model_desc'] = 'моделі Бойынша (Я - A)';
$_['text_limit'] = 'Көрсету:';