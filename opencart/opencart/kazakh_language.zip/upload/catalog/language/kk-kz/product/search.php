<?php
// Heading
$_['heading_title'] = 'Іздеу';
$_['heading_tag'] = 'Тег - ';

// Text
$_['text_search'] = 'Тауарлар, тиісті іздеу';
$_['text_keyword'] = 'tags';
$_['text_category'] = 'Барлық санаттар';
$_['text_sub_category'] = 'Іздеу подкатегориях';
$_['text_empty'] = 'Жоқ тауарларды, тиісті іздеу.';
$_['text_quantity'] = 'Саны:';
$_['text_manufacturer'] = ') Өндіруші:';
$_['text_model'] = 'тауардың Коды:';
$_['text_points'] = 'Бонустық ұпайлар:';
$_['text_price'] = 'Баға:';
$_['text_tax'] = ', ҚҚС-Сыз:';
$_['text_reviews'] = 'негізінде' %s ' пікірлер.';
$_['text_compare'] = 'Салыстыру тауарларды (%s)';
$_['text_sort'] = 'Сұрыптау:';
$_['text_default'] = 'әдепкі';
$_['text_name_asc'] = 'аты Бойынша (А-Я)';
$_['text_name_desc'] = 'аты Бойынша (Я - А) -';
$_['text_price_asc'] = 'баға Бойынша (өсуі)';
$_['text_price_desc'] = 'баға Бойынша (кемуі)';
$_['text_rating_asc'] = 'рейтингі Бойынша (кемуі)';
$_['text_rating_desc'] = 'рейтингі Бойынша (өсуі)';
$_['text_model_asc'] = 'моделі Бойынша (А - Я)';
$_['text_model_desc'] = 'моделі Бойынша (Я - А) -';
$_['text_limit'] = 'Көрсету:';

// Entry
$_['entry_search'] = 'іздестіру Критерийлері';
$_['entry_description'] = 'Искать сипаттамада тауардың';