<?php
// Heading
$_['heading_title'] = ', Тауарлар жеңілдікпен';

// Text
$_['text_empty'] = 'қазіргі уақытта тауарлар жеңілдікпен қол жетімді емес';
$_['text_quantity'] = 'Саны:';
$_['text_manufacturer'] = ') Өндіруші:';
$_['text_model'] = 'тауардың Коды:';
$_['text_points'] = 'Бонустық ұпайлар:';
$_['text_price'] = 'Баға:';
$_['text_tax'] = ', ҚҚС-Сыз:';
$_['text_compare'] = 'Салыстыру тауарларды (%s)';
$_['text_sort'] = 'Сұрыптау:';
$_['text_default'] = 'әдепкі';
$_['text_name_asc'] = 'аты Бойынша (А-Я)';
$_['text_name_desc'] = 'аты Бойынша (Я - А) -';
$_['text_price_asc'] = 'баға Бойынша (өсуі)';
$_['text_price_desc'] = 'баға Бойынша (кемуі)';
$_['text_rating_asc'] = 'рейтингі Бойынша (кемуі)';
$_['text_rating_desc'] = 'рейтингі Бойынша (өсуі)';
$_['text_model_asc'] = 'моделі Бойынша (А - Я)';
$_['text_model_desc'] = 'моделі Бойынша (Я - А) -';
$_['text_limit'] = 'Көрсету:';