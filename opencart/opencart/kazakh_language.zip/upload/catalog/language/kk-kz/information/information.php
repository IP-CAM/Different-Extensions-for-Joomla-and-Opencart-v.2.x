<?php
// Text
$_['text_error'] = 'Бет жоқ!';