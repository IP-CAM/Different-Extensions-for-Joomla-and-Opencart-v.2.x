<?php
// Text
$_['text_subject']	= '%s - Отзыв Товара';
$_['text_waiting']	= 'В ожидании новый отзыв товара.';
$_['text_product']	= 'Товар: %s';
$_['text_reviewer']	= 'Автор: %s';
$_['text_rating']	= 'Рейтинг: %s';
$_['text_review']	= 'Отзыв:';