<?php

$_['text_order']  = 'Получен заказ № ';

