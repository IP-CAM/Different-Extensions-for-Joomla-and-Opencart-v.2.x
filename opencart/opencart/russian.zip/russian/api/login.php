<?php
// Text
$_['text_success'] = 'API сессия успешно запущена!';

// Error
$_['error_key']  = 'ВНИМАНИЕ: Не корректный API Key!';
$_['error_ip']   = 'ВНИМАНИЕ: Ваш  IP %s не добавлен в список доступа к API!';


