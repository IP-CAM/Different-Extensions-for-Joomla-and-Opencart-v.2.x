<?php
// Text
$_['text_currency'] = 'Валюта';

