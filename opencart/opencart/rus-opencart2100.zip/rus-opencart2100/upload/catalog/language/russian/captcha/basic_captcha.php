<?php
// Heading
$_['heading_title'] = 'Защита от роботов';

// Entry
$_['entry_captcha'] = 'Введите код в поле ниже';

// Error
$_['error_captcha'] = 'Проверочный код не совпадает с изображением!';
