<?php defined( '_JEXEC' ) or die; 
if($this->countModules('left and right') == 0) $contentwidth = "_full";
if($this->countModules('left or right') == 1) $contentwidth = "_middle";
if($this->countModules('left and right') == 1) $contentwidth = "_small";
?>
    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru" dir="ltr">

    <head>
        <jdoc:include type="head" />
        <meta name="viewport" content="width=device-width">
        <link rel="shortcut icon" href="/images/favicon.png" type="image/png">
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/personal.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/media.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/lightbox.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/owl.carousel.css" type="text/css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/script.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/owl.carousel.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/maskedinput.js"></script>
    </head>
    <!--AidanaKarabalina26112016-->

    <body>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/lightbox.js"></script> <a id="touch-menu"><span></span><span></span><span></span></a>
        <div id="header">
            <jdoc:include type="modules" name="header" style="xhtml" />
            <div class="container">
                <jdoc:include type="modules" name="menu" style="xhtml" /> </div>
        </div>
        <jdoc:include type="modules" name="pos1" style="xhtml" />
        <jdoc:include type="modules" name="pos2" style="xhtml" />
        <div id="main" class="container">
            <div id="content">
                <div class="jr_component">
                    <?php if($this->countModules('left')) : ?>
                        <div class="jr_left">
                            <jdoc:include type="modules" name="left" style="xhtml" /> </div>
                        <?php endif; ?>
                            <div class="jr<?php echo $contentwidth; ?>">
                                <jdoc:include type="modules" name="breadcrumb" style="xhtml" />
                                <jdoc:include type="component" /> </div>
                            <?php if($this->countModules('right')) : ?>
                                <div class="jr_right">
                                    <jdoc:include type="modules" name="right" style="xhtml" /> </div>
                                <?php endif; ?>
                                    <div class="clr"></div>
                </div>
            </div>
        </div>
        <jdoc:include type="modules" name="pos3" style="xhtml" />
        <div id="footer">
            <jdoc:include type="modules" name="footer" /> </div>
        <div id="back-top" style="display: block;">
            <a href="#"><img src="/images/icon-top.png"></a>
        </div>
        <script>
            jQuery(function ($) {
                $("#back-top").hide();
                $(function () {
                    $(window).scroll(function () {
                        if ($(this).scrollTop() > 50) {
                            $('#back-top').fadeIn();
                        }
                        else {
                            $('#back-top').fadeOut();
                        }
                    });
                    $('#back-top a').click(function () {
                        $('body,html').animate({
                            scrollTop: 0
                        }, 800);
                        return false;
                    });
                });
            });
            jQuery(document).ready(function () {
                jQuery('a#touch-menu').click(function () {
                    if (jQuery('ul.menu').css('display') == 'none') {
                        jQuery('ul.menu').css('display', 'block');
                    }
                    else {
                        jQuery('ul.menu').css('display', 'none');
                    }
                });
            });
        </script>
    </body>

    </html>