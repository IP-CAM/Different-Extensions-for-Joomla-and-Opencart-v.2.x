$(document).ready(function(){
	$('ul.nav a').each(function () {
		if (this.href == location.href) $(this).parent().addClass('active');
	});
});

//Маска для ввода номера телефона
jQuery(function(jQuery){
	jQuery("#form_phone").mask("+7(999) 999-9999");
});