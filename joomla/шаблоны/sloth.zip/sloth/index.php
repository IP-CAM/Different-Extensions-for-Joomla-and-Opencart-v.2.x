<?php defined( '_JEXEC' ) or die;
if($this->countModules('left and right') == 0) $contentwidth = "_full";
if($this->countModules('left or right') == 1) $contentwidth = "_middle";
if($this->countModules('left and right') == 1) $contentwidth = "_small";
?>
 <?php   if($_REQUEST['Itemid']==101){      $classpage = "home-page";  } else{    $classpage = "internal-page";  }?>
    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru" dir="ltr">

    <head>
    	<?php
    unset($this->_scripts[$this->baseurl.'/media/system/js/mootools-core.js'],
          $this->_scripts[$this->baseurl.'/media/system/js/mootools-more.js'],
          $this->_scripts[$this->baseurl.'/media/system/js/core.js'],
          $this->_scripts[$this->baseurl.'/media/jui/js/jquery-noconflict.js'],
          $this->_scripts[$this->baseurl.'/media/system/js/caption.js']);
    $this->_script['text/javascript'] = preg_replace('%jQuery\(window\).on\(\'load\',\s*function\(\)\s*\{\s*new\s*JCaption\(\'img.caption\'\)\;\s*\}\)\;\s*%', '', $this->_script['text/javascript']);
    ?>
        <jdoc:include type="head" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <link rel="shortcut icon" href="/images/favicon.png" type="image/png">

        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/bootstrap/css/bootstrap.min.css">
         <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/bootstrap/css/bootstrap-theme.min.css">
        
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/icomoon.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/jquery.fancybox.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/animate.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/slick.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/slicknav.min.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/owl.carousel.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/owl.theme.default.css" type="text/css" />
        <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
        
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/personal.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/media.css" type="text/css" />

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery.slicknav.min.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/slick.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/owl.carousel.js"></script> 
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/maskedinput.js"></script>
        <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery.fancybox.min.js"></script> 
         <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/script.js"></script>

       


    </head>
    <!--87002133101a@gmail.com-->

      <body class="<?php echo $classpage; ?>"> 
        <div class="containe">
        <header id="header">
            <jdoc:include type="modules" name="header" style="xhtml" />
            <div class="head-top">
                <div class="container">
             <div class="head-menu">
                    <jdoc:include type="modules" name="menu" style="xhtml" />
             </div>
            </div>
            </div>
        </header>
        <section class="block1">
        	<div class="container">
            <jdoc:include type="modules" name="pos1" style="xhtml" />
            </div>
        </section>
        <section class="block2">
        	<div class="container">
            <jdoc:include type="modules" name="pos2" style="xhtml" />
            </div>
        </section>

        <section id="main" class="container">
            <div id="content">
                <div class="jr_component">
                    <?php if($this->countModules('left')) : ?>
                        <div class="jr_left">
                            <jdoc:include type="modules" name="left" style="xhtml" /> </div>
                        <?php endif; ?>
                            <div class="jr<?php echo $contentwidth; ?>">
                                <jdoc:include type="modules" name="breadcrumb" style="xhtml" />
                                  <jdoc:include type="message" />
                                <jdoc:include type="component" /> </div>
                            <?php if($this->countModules('right')) : ?>
                                <div class="jr_right">
                                    <jdoc:include type="modules" name="right" style="xhtml" /> </div>
                                <?php endif; ?>
                                    <div class="clr"></div>
                </div>
            </div>
        </section>

     <section class="block3">
     	<div class="container">
            <jdoc:include type="modules" name="pos3" style="xhtml" />
        </div>
        </section>
         <section class="block4">
         	<div class="container">
            <jdoc:include type="modules" name="pos4" style="xhtml" />
        </div>
         </section>
        <section class="block5">
        	<div class="container">
            <jdoc:include type="modules" name="pos5" style="xhtml" />
        </div>
        </section>
        <section class="block6">
        	<div class="container">
             <jdoc:include type="modules" name="pos6" style="xhtml" />
         </div>
        </section>
        <section class="block7">
        	<div class="container">
            <jdoc:include type="modules" name="pos7" style="xhtml" />
        </div>
        </section>

      </div>
        <footer id="footer">
          <jdoc:include type="modules" name="footer" />
        </footer> 
<!-- Модальное окно -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
      <div class="modal-dialog">
        <div class="modal-content">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">х</button>
          <div class="modal-body">
            <div class="mimage">
              <img src="/images/logo.png">
            </div>
            <form action="/templates/potboiler/post1.php" method="POST" id="form" onsubmit="return checkForm(this)">
              <div id="text3">
                <p class="mod-title"> Оставьте Ваши контактные данные, и получите индивидуальную скидку!
                </p>
                <p><input class="form-control" autocomplete="on" placeholder="Имя" id="form_name" type="text" required="" name="imy"> </p>
                <p><input class="form-control" autocomplete="on" placeholder="+7 707 000 00 00" id="form_phone" required="" type="text" name="telefon"> </p>
                <script>
                  $(function () {
                    $("#form_phone").mask("+7 (999) 999-9999");
                  });
                </script>

                <input class="" type="hidden" name="formDatas" value="Заявка с сайта">
                <input type="submit" value="Отправить" class="btn-send form-control">

              </div>
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">Закрыть</button>
            </form>
          </div>
        </div>
      </div>
    </div>

<!-- кнопка поднять верх! -->
        <div id="back-top" style="display: block;">
            <a href="#"><span class="icon-circle-up"></span></a>
        </div>
        <script>
            jQuery(function ($) {
                $("#back-top").hide();
                $(function () {
                    $(window).scroll(function () {
                        if ($(this).scrollTop() > 50) {
                            $('#back-top').fadeIn();
                        }
                        else {
                            $('#back-top').fadeOut();
                        }
                    });
                    $('#back-top a').click(function () {
                        $('body,html').animate({
                            scrollTop: 0
                        }, 800);
                        return false;
                    });
                });
            });

    /* Мобильное меню */   
    jQuery('.menu').attr("id", "menu2"); 
       jQuery('#menu2').slicknav({ duration: 500, brand: '<a href=""><img src="/images/logo_03.png"></a>'});
      jQuery('span.slicknav_menutxt').text('Меню')
     
        </script>
    </body>

    </html>