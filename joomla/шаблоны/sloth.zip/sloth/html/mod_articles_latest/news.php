<section class="section-block section-block-news">
	<div class="new-block-flex">

	<div class="news-title">

	<div class="col-sm-8 col-xs-8">НОВОСТИ</div>


	</div>

	<div class="col-sm-24">
		<?php foreach ($list as $item) { 

			$image = json_decode($item->images)->image_intro;
			$data =  date('d.m.y', strtotime($item->created));
		?>

			<div class="row new-block new-item">
				<div class="col-sm-8 col-xs-8">
					<div class="row">
						<div class="new-img-block">
							<img src="<?php echo $image; ?>" alt="<?php echo $item->title; ?>">
							<div class="new-data"><?php echo $data; ?></div>
						</div>
					</div>
					
				</div>
				<div class="col-sm-16 col-xs-16 new-block-info">
					<div class="new-block-title"><?php echo $item->title; ?></div>
					<div class="new-block-text"><?php echo $item->introtext; ?><a href="<?php echo $item->link; ?>" class="triner-b">Подробнее</a></div>
					
					
				</div>	
				
			</div>








		<?php } ?>
		<a href="/news" class="news-all"><span>читать все</span><img src="/templates/mytemplate/images/icon-news-arrow.png"></a>
	</div>	

	</div>
</section>
