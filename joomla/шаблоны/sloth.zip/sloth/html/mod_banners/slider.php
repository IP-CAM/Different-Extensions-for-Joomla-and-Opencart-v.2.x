<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_banners
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JLoader::register('BannerHelper', JPATH_ROOT . '/components/com_banners/helpers/banner.php');
$baseurl = JUri::base();
?>

<div class="header-slider">

	<div id="slideshow">
		<?php foreach ($list as $item) : 
		$data =  date('d.m.y', strtotime($item->created));
		?>
	
		<?php $imageurl = $item->params->get('imageurl');?>
				<div class="item">
					<img src="<?php echo $baseurl . $imageurl;?>" alt="">	
					<div class="slider-ab-block">
						<div class="slid-data">
							
						</div>
						<div class="slid-desc">
							<?php echo mb_strimwidth($item->description, 0, 100, "...");?><a href="<?php echo $item->clickurl; ?>"><span>Подробнее</span></a>
						</div>
					</div>
					
				</div>
				
		<?php endforeach; ?>
	</div>


</div>
<script type="text/javascript">

	$('#slideshow').owlCarousel({
	  items: 1,
	  animateOut: 'fadeOut',
	  autoplay:true,
      autoplayTimeout:5000,
      autoplayHoverPause:true,
	  loop: true,
	  stopOnHover: true,
	  singleItem: true
	});
</script>