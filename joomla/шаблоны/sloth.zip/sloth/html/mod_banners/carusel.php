<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_banners
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JLoader::register('BannerHelper', JPATH_ROOT . '/components/com_banners/helpers/banner.php');
$baseurl = JUri::base();
?>

<div class="header-slider">

	<div id="carusel-part">
		<?php foreach ($list as $item) : 
		$data =  date('d.m.y', strtotime($item->created));
		?>
	
		<?php $imageurl = $item->params->get('imageurl');?>
				<div class="item">
					<a href="<?php echo $item->clickurl; ?>"><img src="<?php echo $baseurl . $imageurl;?>" alt=""></a>
				</div>
				
		<?php endforeach; ?>
	</div>


</div>
<script type="text/javascript">

	$('#carusel-part').owlCarousel({
	  items: 7,
	  autoplay:true,
      autoplayTimeout:3000,
	  loop: true,
	  responsive:{
	  	0:{
            items:2
        },
	  	480:{
            items:2
        },
        767:{
            items:4
        },
        1200:{
            items:7
        },
    }
	});
</script>