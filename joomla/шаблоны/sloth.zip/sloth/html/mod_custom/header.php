<div class="heder-top">
	<div class="container">

	    <div class="row flex-vert-h header-t">
	        <div class="col-lg-8 col-md-10 col-sm-12 col-xs-7 flex-vert-c">

				<div class="logo-block">
					<a href="" class="logo">
						<img src="/templates/mytemplate/images/logo.png" >
					</a>
				</div>
				<div class="l-grid-text">
					Уполномоченный по правам человека в Республике Казахстан
				</div>
				
			</div>
	        <div class="col-lg-4 col-lg-offset-12 col-md-6 col-md-offset-8 col-sm-8 col-sm-offset-4 col-xs-12 flex-vert-c flex-hor-r">
	        	<div>
		        	<div class="header-block-sl">
		        		<a href="" class="header-soc header-fas"><img src="/templates/mytemplate/images/icon-facebook.png"></a>
		        		<a href="" class="header-soc header-you"><img src="/templates/mytemplate/images/icon-youtube.png"></a>
		        		<div class="l-grid-leng">
									<?php 
									jimport( 'joomla.application.module.helper' ); 
									$modules = JModuleHelper::getModules( 'language');  
									$attribs['style'] = 'xhtml'; 
									foreach($modules as $module){ 
									echo JModuleHelper::renderModule($module, $attribs); 
									} 
									?>
								
						</div>
		        	</div>
			        <div class="header-block-sl">
			 <!--        	<a href="">Черно-белый</a> -->
			        	<a href="#" class="bvi-panel-open">Версия для слабовидящих</a> 
			        </div>
		        </div>

	        </div>
	         <div class="col-xs-5 visible-xs hidden-sm top-mi">
              <a href="#" id="hamburger" class="mm-slideout">
                <span class="hamburger hamburger--collapse">
                  <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                  </span>
                </span>
              </a>
            </div>
	    </div>
	</div>
</div>
<nav id="menu-adapt">
	<?php 
	jimport( 'joomla.application.module.helper' ); 
	$modules = JModuleHelper::getModules( 'menu');  
	$attribs['style'] = 'xhtml'; 
	foreach($modules as $module){ 
	echo JModuleHelper::renderModule($module, $attribs); 
	} 
	?>
							
</nav>
<div class="heder-bottom">
	<div class="container">

	    <div class="row">
			<div class="top-menu">
				<?php 
				jimport( 'joomla.application.module.helper' ); 
				$modules = JModuleHelper::getModules( 'menu');  
				$attribs['style'] = 'xhtml'; 
				foreach($modules as $module){ 
				echo JModuleHelper::renderModule($module, $attribs); 
				} 
				?>
			</div>
	    </div>

	</div>
</div>

<script type="text/javascript">
	 jQuery(document).ready(function () {1
        jQuery(function (jQuery) {
          var content_height1 = jQuery('#header').offset().top;
          jQuery(window).scroll(function () {
            var top = jQuery(document).scrollTop();
            if (top > content_height1) jQuery('#header').addClass('fixed1');
            else jQuery('#header').removeClass('fixed1');
          });
        });
      });
</script>
<script type="text/javascript">
    t = jQuery("html");

    var c = jQuery("#menu-adapt").mmenu({
        "slidingSubmenus": true,
      extensions: {
        all: ["theme-white", "fx-menu-zoom",
                  "fx-panels-zoom", "pagedim-black", "pagedim-black"],
        "(min-width: 1430px)": ["widescreen"]
      },
    navbar: {
      title: "Категории"
     }, //меняем заголовок. Можно использовать теги. Подробнее об аддоне navbar можно найти тут http://mmenu.frebsite.nl/documentation/addons/navbars.html
     pageScroll : {
    //  scroll : true, // прокрутка к якорю
    //  update : true, //прокручивать, даже если пункт обозначен как активный
     scrollOffset : 300 // отступ от якоря, по умолчанию 0. У меня почему-то не заработал :(
    }
   }).data("mmenu"),
    d = jQuery("#hamburger").on("click", function(e) {
      e.preventDefault(), t.hasClass("mm-opened") ? c.close() : c.open()
    }).children(".hamburger");
    c.bind("close:finish", function() {
      setTimeout(function() {
        d.removeClass("is-active")
      }, 100)
    }), c.bind("open:finish", function() {
      setTimeout(function() {
        d.addClass("is-active")
      }, 100)
    })
</script> 