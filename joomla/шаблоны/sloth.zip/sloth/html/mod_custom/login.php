<div class="block-login">

	<div class="block-login-title">войти в NPM сеть</div>
	<form action="" id="login" class="login">
		<input type="text" id="form_login" name="login" value="" placeholder="Имя пользователя">
		<input type="text" id="form_password" name="password" value="" placeholder="Пароль">


		<label class="container">Запомнить меня на этом компьютере
		  <input type="checkbox" id="radioButton" name="remember">
		  <span class="radiobtn"></span>
		</label>
		<div class="b-login">
			<input type="submit" value="Войти">
			<a href="" class="f-y-password">Забыли пароль?</a>
		</div>
		

	</form>


</div>