<?php
/**
 * @package PLG_TWCDISCLAIMER for Joomla!
 * @version $Id: twcdisclaimer.php 1.0.0 2015-11-21 12:00:00
 * @author Terry Carter
 * @copyright (C) 2015 - Terry W. Carter.
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/

//NO DIRECT ACCESS
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemTWCDisclaimer extends JPlugin
{
	public function __construct(&$subject, $config = array()) {
        parent::__construct($subject, $config);
		
		//GET USER
		$this->user				= JFactory::getUser();
		$this->guest 			= $this->user->guest;
		$this->isAdmin 			= $this->user->get('isRoot');
		$this->doc 				= JFactory::getDocument();
		$this->is_site 			= JFactory::getApplication()->getName() == 'site';
		$this->twcplg_params 	= json_decode(JPluginHelper::getPlugin('system','twcdisclaimer')->params, TRUE);
		
		//PLUGIN SETTINGS
		$this->menuItemids 		= $this->twcplg_params['idarray'];
		$this->theme 			= $this->twcplg_params['theme'];
		$this->title 			= $this->twcplg_params['title'];
		$this->content 			= $this->twcplg_params['content'];
		$this->confirmText 		= $this->twcplg_params['confirmtext'];
		$this->confirmBtnStyle 	= $this->twcplg_params['confirmbtnstyle'];
		$this->cancelText 		= $this->twcplg_params['canceltext'];
		$this->cancelBtnStyle 	= $this->twcplg_params['cancelbtnstyle'];
		$this->closeIcon 		= $this->twcplg_params['closeicon'];
		$this->keyboard 		= $this->twcplg_params['keyboard'];
		$this->backgroundClose 	= $this->twcplg_params['backgroundclose'];
		$this->redirectURL 		= $this->twcplg_params['redirecturl'];
		$this->cookiedays 		= $this->twcplg_params['cookiedays'];
		$this->cookiepath 		= $this->twcplg_params['cookiepath'];
		$this->autoClose 		= $this->twcplg_params['autoclose'];
		$this->autoCloseTime 	= $this->twcplg_params['autoclosetime'];
		$this->registeredUsers 	= $this->twcplg_params['registeredUsers'];
		$this->debug 			= $this->twcplg_params['debug'];
		
		if($this->isAdmin && $this->debug && $this->is_site){
			echo '<pre>';
			print_r($this->twcplg_params);
			echo '</pre>';
		}
	}
	
	public function onBeforeRender()
	{
		
		
		//GET INPUTS
		$JInput		= JFactory::getApplication()->input;
		$Itemid 	= $JInput->get('Itemid','','int');
		
 		if($this->is_site)
		{
			if(!empty($this->menuItemids))
			{
				if(in_array($Itemid, $this->menuItemids))
				{
					//ADD SCRIPTS AND STYLE TO DOC
					$this->doc->addStyleSheet( "plugins/system/twcdisclaimer/assets/css/twcdisclaimer.css", "text/css", "screen");
					//JHtml::_('script', 'plugins/system/twcdisclaimer/assets/js/twcdisclaimer.js');
					//JHtml::_('script', 'plugins/system/twcdisclaimer/assets/js/cookie.js');
				}
			}
    	}
	}
	
	
	public function onAfterRender()
	{	
		//GET INPUTS
		$JInput		= JFactory::getApplication()->input;
		$Itemid 	= $JInput->get('Itemid','','int');
		
 		if($this->is_site)
		{
			if(!empty($this->menuItemids))
			{
				if(in_array($Itemid, $this->menuItemids))
				{
					$debug = true;
					$disclaimer = "
						<script type='text/javascript'>
						jQuery(document).ready(function($){
							//CHECK COOKIE VALUE
							".(($this->debug && $this->isAdmin)? '$.removeCookie("simplecontentdisclaimer", { path: "'.$this->cookiepath.'" });':'')."
							if(!$.cookie('simplecontentdisclaimer')){
								//OPEN AGE CONFIRMATION BOX
								$.confirm({
									theme: '".$this->theme."',
									title: ".(($this->title != 'Default' && $this->title != 'PLG_SYSTEM_TWCDISCLAIMER_TITLE_DEFAULT') ? '"'.$this->title.'"' : 'false').",
									content: ".(($this->content != '') ? json_encode($this->content) : 'false').",
									confirmButton: '".$this->confirmText."',
									".(($this->theme == 'white' || $this->theme == 'black')? "confirmButtonClass: '".$this->confirmBtnStyle."',":'')."
									cancelButton: '".$this->cancelText."',
									".(($this->theme == 'white' || $this->theme == 'black')? "cancelButtonClass: '".$this->cancelBtnStyle."',":'')."
									closeIcon: ".(($this->closeIcon) ? 'false' : 'true').",
									backgroundDismiss: ".(($this->backgroundClose) ? 'true' : 'false').",
									keyboardEnabled: ".(($this->keyboard) ? 'true' : 'false').",
									".(($this->autoClose) ? "autoClose: 'cancel|".$this->autoCloseTime."'" : 'autoClose: false').",
									confirm: function(){
										//GET PREVIOUS COOKIE OR SET NEW COOKIE
										var simplecontentdisclaimer = $.cookie('simplecontentdisclaimer') || 1;
										$.cookie('simplecontentdisclaimer', simplecontentdisclaimer, { expires: ".$this->cookiedays.", path: '".$this->cookiepath."' });
										console.log($.cookie('simplecontentdisclaimer'));
									},
									cancel: function(){
										window.location.href = '".$this->redirectURL."';
									}
								});	
							}else{
								//LOG TO CONSOLE IF PREVIOUS VISITOR
								//console.log($.cookie('simplecontentdisclaimer'));
							}
						});
						</script>
					";
					$disclaimer .= '';
					$disclaimer .= '</body>';
					
					if($this->registeredUsers || $this->guest || ($this->isAdmin && $this->debug)){
						JResponse::setBody(str_ireplace('</body>',$disclaimer,JResponse::getBody()));
					}
				}
			}
    	}
	}
}
?>
