<?php

namespace InstagramScraper;


class InstagramQueryId
{
    /**
     * id = {{accoundId}}, first = {{count}}, after = {{mediaId}}
     */
    const USER_MEDIAS = '17880160963012870';

}