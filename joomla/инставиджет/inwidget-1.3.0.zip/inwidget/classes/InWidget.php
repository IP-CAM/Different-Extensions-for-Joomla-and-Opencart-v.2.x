<?php

require_once __DIR__ . '/InWidget/Exception/inWidgetException.php';
require_once __DIR__ . '/InWidget/API/apiModel.php';
require_once __DIR__ . '/InWidget/API/apiScraper.php';
require_once __DIR__ . '/InWidget/API/apiOfficial.php';
require_once __DIR__ . '/InWidget/Core.php';