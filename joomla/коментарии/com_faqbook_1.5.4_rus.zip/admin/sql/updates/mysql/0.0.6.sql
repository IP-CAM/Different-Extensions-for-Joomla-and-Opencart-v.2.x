CREATE TABLE IF NOT EXISTS `#__faqbookpro_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
	`catid` int(11) NOT NULL DEFAULT '0',
	`published` tinyint(1) NOT NULL DEFAULT '0',
	`content` mediumtext NOT NULL,
	`creator` int(11) NOT NULL DEFAULT '0',
	`ordering` int(11) NOT NULL DEFAULT '0',
	`votes_up` int(11) NOT NULL DEFAULT '0',
	`votes_down` int(11) NOT NULL DEFAULT '0',
	`checked_out` int(10) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
	`access` int(11) NOT NULL DEFAULT '0',
	`params` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
