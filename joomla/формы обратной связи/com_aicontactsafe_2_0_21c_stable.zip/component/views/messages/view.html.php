<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// load the view
require_once( JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_aicontactsafe'.DS.'views'.DS.'messages'.DS.'view.html.php' );
