<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

// load the model
require_once( JPATH_ROOT.DS.'administrator'.DS.'components'.DS.'com_aicontactsafe'.DS.'models'.DS.'messages.php' );
