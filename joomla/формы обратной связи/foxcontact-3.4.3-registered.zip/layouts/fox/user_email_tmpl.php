<?php defined("_JEXEC") or die(file_get_contents("index.html")); ?>
<div class="wrapper">
	<div class="container">
		<div class="inner">
			<div class="header sitename">{sitename}</div>
			<p><?php echo JText::_("COM_FOXCONTACT_EMAIL_COPY_BODY_DFLT") ?></p>
			<div class="footer">© {sitename}</div>
		</div>
	</div>
</div>
