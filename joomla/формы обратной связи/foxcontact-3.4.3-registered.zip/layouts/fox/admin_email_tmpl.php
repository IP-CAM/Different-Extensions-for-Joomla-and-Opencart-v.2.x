<?php defined("_JEXEC") or die(file_get_contents("index.html")); ?>
<div class="wrapper">
	<div class="container">
		<div class="inner">
			<div class="header sitename">{sitename}</div>
			{field-table-full}
			<div class="footer">© {sitename}</div>
		</div>
	</div>
</div>
