DELETE FROM `#__modules` WHERE `module` = 'mod_foxcontact' AND `published` = 0;
