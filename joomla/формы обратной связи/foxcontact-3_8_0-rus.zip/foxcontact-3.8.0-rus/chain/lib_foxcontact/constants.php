<?php defined('_JEXEC') or die(file_get_contents('index.html'));
/**
 * @package   Fox Contact for Joomla
 * @copyright Copyright (c) 2010 - 2015 Demis Palma. All rights reserved.
 * @license   Distributed under the terms of the GNU General Public License GNU/GPL v3 http://www.gnu.org/licenses/gpl-3.0.html
 * @see       Documentation: http://www.fox.ra.it/forum/2-documentation.html
 */
define('MB0', 0);
define('MB1', 1048576);
define('MB2', 2097152);
define('MB5', 5242880);
define('MB10', 10485760);
define('MB20', 20971520);
define('MB50', 52428800);
define('MB100', 104857600);
define('MB200', 209715200);
define('MB500', 524288000);