<?php
/**
* @version      4.7.0 13.08.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');

class JshoppingViewOrder extends JViewLegacy{
    function display($tpl = null){
        parent::display($tpl);
	}
}
?>