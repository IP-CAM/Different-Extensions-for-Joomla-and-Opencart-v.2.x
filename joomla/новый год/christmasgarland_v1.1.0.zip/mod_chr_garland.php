<?php
defined('_JEXEC') or die();

require(JModuleHelper::getLayoutPath('mod_chr_garland', $params->get('layout', 'default')));
require_once dirname(__FILE__).'/helper.php';
$list = modChrgarlandHelper::getList($params);
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));