﻿<?php
/**
* About block Element
* @package News Show Pro GK4
* @Copyright (C) 2009-2011 Gavick.com
* @ All rights reserved
* @ Joomla! is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @version $Revision: GK4 1.0 $
**/
defined('JPATH_BASE') or die;
jimport('joomla.form.formfield');
class JFormFieldAbout extends JFormField {
	protected $type = 'About';
	protected function getInput() {
	return '
    <style>#jform_params_about_us-lbl {display:none;}#jform_params_stylecarus {width:100%!important; height:230px!important;}</style>
<div style="margin-bottom:5px;font-size: 14px;">Автор: <a href=\'http://blogprogram.ru\' target=\'_blank\'>blogprogram.ru</a></div>
<div style="
    font-size: 19px;
">Модуль позволяет выводить материалы с картинками, которые необходимо добавлять в превью к материалу. Подробнее о модуле: <a target="_blank" href="http://blogprogram.ru/modules-posledniye-dobavlenniye-materiali-joomla25-3" >здесь</a>.</div>';
	}
}
/* eof */
