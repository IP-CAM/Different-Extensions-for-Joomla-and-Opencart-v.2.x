<div class="heder-top section-block-contact">
	<div class="top-menu">
		<div class="container">
			<?php 
			jimport( 'joomla.application.module.helper' ); 
			$modules = JModuleHelper::getModules( 'menu');  
			$attribs['style'] = 'xhtml'; 
			foreach($modules as $module){ 
			echo JModuleHelper::renderModule($module, $attribs); 
			} 
			?>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="row flex-order">
			
			<div class="col-sm-6 col-xs-12 footer-bottom-block">

				<div class="footer-link">
					<div class="footer-title-botom">
						Полезные ссылки:
					</div>
					<div class="footer-link-item">
						<a href="">Ссылка</a>
						<a href="">Ссылка</a>
						<a href="">Ссылка</a>
						<a href="">Ссылка</a>
						<a href="">Ссылка</a>
						<a href="" class="sitemap-footer">Карта сайта</a>
					</div>

					<div class="footer-copy">
						<a href="https://abc-design.kz/" target="_blank" class="footer-cop">Разработано в ABC DESIGN - создание сайтов в Астане | продвижение сайтов в Астане</a>
					</div>

				</div>

			</div>

			<div class="col-sm-18 col-xs-12 footer-bottom-block">
				<div class="row">
					<div class="col-sm-9 col-sm-offset-2">
						<div class="footer-title-botom">
							Подпешись и будь в курсе всех событий:
						</div>


						<div class="col-sm-24">
							<div class="row">
				                <div class="col-sm-24">
				                	<div class="row">
				                		<form action="" id="form" class="form">
				                        	<input type="text" id="popup-form_mail" name="mail" value="" placeholder="E-mail*">
				                        	<input type="submit" value="Apply">
				                        </form>
			                        </div>
				                </div>
							</div>
						</div>

						<div class=" col-sm-24">
							<div class="row  ">
								<div class="footer-soc-seti footer-title-botom">Мы в соц.сетях:</div>
								<a href="" class="soc-footer-icon soc-footer-icon-faseboock"><img src="/templates/mytemplate/images/footer-icon-facebook.png" alt="placeholder+image"></a>
								<a href="" class="soc-footer-icon soc-footer-icon-youtube"><img src="/templates/mytemplate/images/footer-icon-youtube.png" alt="placeholder+image"></a>
							</div>
							
							
						</div>
						<div class=" col-sm-24">
							<div class="row  ">
								
								<div class="footer-adres">
									<p class="footer-cop">Разработано в ABC DESIGN - создание сайтов в Астане | продвижение сайтов в Астане</p>
								</div>

							</div>

						</div>



						
					</div>



					<div class="col-sm-11 col-sm-offset-2">
						


						<div class="col-sm-24">
							<div class="row">
				               <div class="logo-block">
									<a href="" class="logo">
										<img src="/templates/mytemplate/images/logo-footer.png" alt="placeholder+image">
									</a>
								</div>
							</div>
						</div>

						<div class="col-sm-24">
							<div class="row">
				               <div class="footer-title-botom footer-title-right">
									Уполномоченный по правам человека Республики Казахстан
								</div>
							</div>
						</div>
						<div class="col-sm-24">
							<div class="row">
				               <div class="footer-title-botom  footer-phone-right">
									<a href="tel:87777777777">8 (7172) 74 05 48</a><span>(факс)</span>
								</div>
							</div>
						</div>
						<div class="col-sm-24">
							<div class="row">
				               <div class="footer-title-botom  footer-mail-right">
									<a href="mailto:info@nhri.kz">info@nhri.kz</a>
									<a href="mailto:ombudsman-kz@mail.ru">ombudsman-kz@mail.ru</a>
								</div>
							</div>
						</div>

						<div class="col-sm-24">
							<div class="row">
								
				               <div class="footer-title-botom  footer-mail-right">
				               	<div class="footer-title-botom">
									Время приема:
								</div>
									<p>Со вторника по пятницу (10.00-16.00)</p>
									<p>Перерыв с 13.00-14.30</p>
								</div>
							</div>
						</div>
						


						
					</div>
				</div>




			</div>

		</div>

	</div>
</div>






	