<h1 class="category_title">
<?php echo $this->escape($this->item->title); ?>
</h1>
<div class="section-about-block-text">
	<?php echo $this->item->text; ?>
</div>