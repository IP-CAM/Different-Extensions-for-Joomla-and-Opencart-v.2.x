
<?php 
    $img = json_decode($this->item->images)->image_intro;
 ?>
<div class="products-blog">
    <div class="product-img col-sm-8">
        <img src="<?php echo $img ?>" alt="">
    </div>
    <div class="product-text col-sm-16"> 
    	<h1 class="category_title">
			<?php echo $this->escape($this->item->title); ?>
		</h1>
        <div class="category_drsc">
        	<?php echo $this->item->text; ?>
        	
        </div>
    </div>
    
</div>