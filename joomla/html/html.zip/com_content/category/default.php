<div class="category_title ">
    <?php echo $this->category->title; ?>
</div>
<div class="category-desc">
	<?php echo $this->category->description; ?>
</div>

<div class="category-products-blog grid" itemscope itemtype="http://schema.org/Blog">

    <?php 
    foreach($this->items as $item){ ?>
    <?php
    $link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catid, $item->language));
    if(json_decode($item->images)->image_intro != ''){
        $img = json_decode($item->images)->image_intro;
    }else{
        $img = "/images/sample.png";
    }    
    ?>
	<div class="col-sm-6 triner-block">
		<a href="<?php echo $link; ?>" class="triner-b">
			<div class="triner-img-block">
				<img src="<?php echo $img; ?>" alt="1">
			</div>
		
			<div class="transp-item-title"><?php echo $item->title; ?></div>
		</a>
	</div>

    <?php } ?>

    
    <div class="col-sm-12 col-xs-12">
        <?php // Add pagination links ?>
        <?php if (!empty($this->items)) : ?>
        	<?php if (($this->params->def('show_pagination', 2) == 1  || ($this->params->get('show_pagination') == 2)) && ($this->pagination->pagesTotal > 1)) : ?>
        		<div class="pagination">
        			<?php echo $this->pagination->getPagesLinks(); ?>
        		</div>
        	<?php endif; ?>
        <?php endif; ?>
    </div>

</div>