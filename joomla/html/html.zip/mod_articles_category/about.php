<section class="section-block section-block-treiner section-block-about">
	<div class="container">
		<div class="section-title-block col-sm-3">
			<div class="section-title">Кто мы?</div>
		</div>
		
		<div class="col-sm-21">
			<h1 class="section-treiner-text section-about-text"> <?php echo $list[0]->title; ?>	</h1>
			<div class="section-about-desc"> <?php echo $list[0]->introtext; ?>	</div>
			<div class="section-about-linck"><a href="<?php echo $list[0]->link; ?>">Читать дальше</a></div>
		</div>
		
		
	</div>
</section>