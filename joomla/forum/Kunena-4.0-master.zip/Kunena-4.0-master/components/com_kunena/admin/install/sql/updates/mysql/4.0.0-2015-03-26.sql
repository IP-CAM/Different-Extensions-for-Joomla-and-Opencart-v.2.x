ALTER TABLE `#__kunena_categories` ADD COLUMN `icon` varchar(20) NOT NULL	DEFAULT '' AFTER `alias`
