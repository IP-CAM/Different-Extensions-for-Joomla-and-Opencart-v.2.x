-- Kunena 2.0

ALTER TABLE	`#__kunena_polls_users`		CHANGE `lasttime` `lasttime` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00';
