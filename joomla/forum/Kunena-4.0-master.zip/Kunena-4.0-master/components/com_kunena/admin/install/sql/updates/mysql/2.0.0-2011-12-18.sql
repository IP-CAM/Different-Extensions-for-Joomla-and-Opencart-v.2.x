-- Kunena 2.0

ALTER TABLE	`#__kunena_announcement`	ADD `created_by` int(10) NOT NULL AFTER `title`;
