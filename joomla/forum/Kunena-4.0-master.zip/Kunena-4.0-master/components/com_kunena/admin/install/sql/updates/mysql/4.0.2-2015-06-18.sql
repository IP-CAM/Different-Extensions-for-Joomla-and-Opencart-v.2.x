ALTER TABLE `#__kunena_categories` CHANGE COLUMN `icon` `icon` VARCHAR(60)
