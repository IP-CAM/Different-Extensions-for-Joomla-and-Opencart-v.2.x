
Kunena Statistics Module README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Statistics 3.1.2!

INTRODUCTION
============

Kunena Statistics enables your site visitors to see Statistics from forum in a Joomla! module.

Requirements: Joomla 2.5, Kunena Forum 2.0

END OF README
=============
