
Kunena Latest Module README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Latest 3.1.2.1!

INTRODUCTION
============

Kunena Latest Module enables your site visitors to see latest posts or messages from a forum.

Requirements: Joomla 2.5, Kunena Forum 2.0

END OF README
=============
