
Kunena Search Module README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Search 3.1.2!

INTRODUCTION
============

Kunena Search enables your site visitors to use the kunena search in a Joomla! module.

Requirements: Joomla 2.5, Kunena Forum 2.0

END OF README
=============
