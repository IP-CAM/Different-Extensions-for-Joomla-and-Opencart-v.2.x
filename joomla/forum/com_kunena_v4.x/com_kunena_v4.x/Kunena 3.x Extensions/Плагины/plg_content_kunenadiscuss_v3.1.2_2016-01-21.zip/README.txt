Kunena Discuss Plugin README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Discuss 3.1.2!

INTRODUCTION
============

Kunena Discuss enables your site visitors to discuss your content articles in designated forum categories.

Requirements: Joomla! 2.5 and 3.x, Kunena Forum 3.0

END OF README
=============
