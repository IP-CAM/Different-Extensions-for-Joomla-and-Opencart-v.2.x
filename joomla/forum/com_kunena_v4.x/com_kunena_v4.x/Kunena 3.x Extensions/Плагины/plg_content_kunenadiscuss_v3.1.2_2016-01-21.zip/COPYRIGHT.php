<?php
/**
 * Kunena Discuss Plugin
 * @package Kunena.plg_content_kunenadiscuss
 *
 * @copyright (C) 2008 - 2016 Kunena Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.kunena.org
 **/
die('');
?>

<!--

Kunena Discuss derives from copyrighted works licensed under the GNU General
Public License. This version has been modified pursuant to the
GNU General Public License as of September 15, 2005, and as distributed,
it includes or is derivative of works licensed under the GNU General
Public License or other free or open source software licenses, including
works copyrighted by any or all of the following:

SimpleBoard Discussbot (C) 2000-2006 Two Shoes M-Factory
FireBoard Discussbot (C) 2007-2008 ObjectClarity.com
Kunena Discuss (C) 2009 Jaroslav Kadubec

-->
