Kunena Search Plugin README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Search 3.1.2!

INTRODUCTION
============

Kunena Search enables your site visitors to see in joomla! search results the things from Kunena.

Requirements: Joomla! 2.5 and 3.x, Kunena Forum 3.0

END OF README
=============
